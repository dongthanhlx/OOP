
public class TestDiagram {
	public static void main(String[] args){
		Shape[] shapeList = new Shape[6];
		shapeList[0] = new Triangle(1, 5, 7);
		shapeList[1] = new Circle(2, 4, 5);
		shapeList[2] = new Rectangle(1, 5,7 ,9);
		shapeList[3] = new Square(7, 3, 4);
		shapeList[4] = new Triangle(1, 3, 4);
		shapeList[5] = new Triangle(4, 6, 9);
		
            for (Shape shapeList1 : shapeList) {
                shapeList1.draw();
            }
		
		System.out.println(" ");
		
		Layer layer1 = new Layer(shapeList);
		int p = layer1.eraseTriangle();
		for(int i = 0; i < p; i++)
		{
			shapeList[i].draw();
		}
                System.out.println("");
                Diagram diagram1 = new Diagram(shapeList);
                int q = diagram1.eraseCircle();
                for(int i=0 ; i<q ; i++)
                {
                    shapeList[i].draw();
                }
                
	}
}
