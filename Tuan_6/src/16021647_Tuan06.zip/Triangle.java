
public class Triangle extends Shape{
int side;
	
	public Triangle(int x, int y, int side)
	{
		super(x, y);
		this.side = side;
	}
	
        @Override
	public void draw()
	{
		System.out.println("Draw triangle at (" + x + ", " + y + ")");
	}
}
