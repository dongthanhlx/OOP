
public class Square extends Shape{
	int side;
	
	public Square(int x, int y, int side)
	{
		super(x, y);
		this.side = side;
	}
	
        @Override
	public void draw()
	{
		System.out.println("Draw square at (" + x + ", " + y + ")");
	}
}
