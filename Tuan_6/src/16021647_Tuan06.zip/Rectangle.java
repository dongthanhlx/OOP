
public class Rectangle extends Shape{
	int height;
	int width;
	
	public Rectangle(int x, int y, int height, int width)
	{
		super(x, y);
		this.height = height;
		this.width = width;
	}

        @Override
	public void draw()
		{
			System.out.println("Draw rectangle at (" + x + ", " + y + ")");
		}
}
