
public class Layer {
	Shape[] shapes = new Shape[100];
	Layer(Shape[] shapes)
	{
		this.shapes = shapes;
	}
	
	
	public int eraseTriangle()
	{
		int n = shapes.length;
		for (int i = 0; i < n; i++)
		{
			if (shapes[i] instanceof Triangle){
			
				int j = i;
				while (j < n-1){
					shapes[j] = shapes[j+1];
					j++;
				}
				n--;
				i--;
			}
		}
		return n;
	}
        
}
