package Shapes;

public class book {
	private int gia;
	private String name;
	public book(String name){
		this.name = name;
	}
	public void setGia(int gia){
		this.gia = gia;
	}
	public void setName(String name){
		this.name = name;
	}
	public int getGia(){
		return gia;
	}
	public String getName(){
		return name;
	}
}
